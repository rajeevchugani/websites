$("#signup").click(alert_me);

function alert_me() {
	alert("We're Not Ready For Sign­Ups.... Yet");
});